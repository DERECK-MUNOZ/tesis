// Services
export { CustomersService } from './fake/customers.service'; // You have to comment this, when your real back-end is done
export { ProductsService } from './fake/products.service'; // You have to comment this, when your real back-end is done
export { SpecificationsService } from './fake/specifications.service'; // You have to comment this, when your real back-end is done
export { RemarksService } from './fake/remarks.service'; // You have to comment this, when your real back-end is done
// export { CustomersService } from './customers.service'; // You have to uncomment this, when your real back-end is done
// export { ProductsService } from './products.service'; // You have to uncomment this, when your real back-end is done
// export { SpecificationsService } from './specifications.service'; // You have to uncomment this, when your real back-end is done
// export { RemarksService } from './remarks.service'; // You have to uncomment this, when your real back-end is done
