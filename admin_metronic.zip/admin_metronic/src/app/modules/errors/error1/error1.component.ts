import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error1',
  templateUrl: './error1.component.html',
})
export class Error1Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
