import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-state-user',
  templateUrl: './change-state-user.component.html',
  styleUrls: ['./change-state-user.component.scss']
})
export class ChangeStateUserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
