import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dropdown-menu2',
  templateUrl: './dropdown-menu2.component.html',
})
export class DropdownMenu2Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
